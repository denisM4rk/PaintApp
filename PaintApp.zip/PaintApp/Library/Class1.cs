using System;

namespace Library
{
    public class Class1
    {
        public static void CloseWindow()
        {
            Environment.Exit(0);
        }
    }
}
